This is an artificially intelligent backprop neural network 
with 2 inputs and one output. Very simple code with lots of 
comments on how the neural network is designed to work. 
If you like it, there is more A.I. at http://www.rgsoftware.com
If you have questions about this code or neural networks 
in general, just send me an email: rgardner@rgsoftware.com
You can also download my genetic algorithm on planet-source-code.com

What are Artificial Neural Networks? 
Artificial Neural Networks are computational paradigms which implement simplified models of their biological counterparts, biological neural networks. Biological Neural Networks are the local assemblages of neurons and their dendrite connections that form the (human) brain. 

The implementation of Neural Networks for brain-like computations like patterns recognition, decisions making, motory control and many others is made possible by the advent of large scale computers in the late 1950's. 

Conventional computers rely on programs that solve a problem using a pre-determined series of steps, called algorithms. These programs are controlled by a single, complex central processing unit, and store information at specific locations in memory. Artificial Neural Networks use highly distributed representations and transformations that operate in parallel, have distributed control through many highly interconnected neurons, and store their information in variable strength connections called synapses � just like a human brain.

To train a neural network you must have a data set containing sample parameters which corresponding to the results. The data used for training is usually obtained using historical data in which the outcomes are known.

You can also train a neural network by creating sample problems and answers. Once the training process is completed, the neural network will be able to predict answers when new inputs are processed.